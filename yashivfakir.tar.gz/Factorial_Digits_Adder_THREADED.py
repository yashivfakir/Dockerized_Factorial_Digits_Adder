"""###############################################################################################################################
                                                    CORIGINE FACTORIAL CHALLENGE
                                        (Summation of Factorial Output Digits in Python3)

                                                    Created by: Yashiv Fakir
                                                    Created on: 14/04/2022
                                                            Version: 3
###############################################################################################################################"""

import numpy as np                                  # Used for all math operation
import argparse                                     # Control input between container and script
import time                                         # Used to measure execution time
from Threads_Math_Class import Multiplier           # Support class for factorial multiplication
from Thread_Class import Threader                   # Support class for factorial partitioning




def factorial(input):
    
    ##############################################################
    ### Determine the factorial and parse into the zeros array ###
    ##############################################################
 
    # Maximum number of digits allowed for the factorial output
    MAX_Number_Of_Factorial_Output_Digits = 50000

    if (input < 2):
        # If the input number 1 or 0, then the factorial is 1 
        
        factorial_Array = [1]
        factorial_Sum(factorial_Array, 1)

    elif(input <= 2000):
        # If the input number is <= 2000, then it is faster to execute in a sequential manner 

        factorial_Array = [0] * MAX_Number_Of_Factorial_Output_Digits
        factorial_Array[0] = 1
        actual_Array_Size = 1 # actual_Array_Size counts the number of amended elements in the array that changed from zero to the amended number
    
        # Start factorial multiplication at 2
        i = 2

        # Determine factorial beginning at 2
        while i <= input:
            factorial_Array = Multiplier.array_Int_Multiplier(i, actual_Array_Size, factorial_Array)
            actual_Array_Size = factorial_Array[MAX_Number_Of_Factorial_Output_Digits - 1]
            # Increment the factorial multiplier
            i = np.add(i, 1)  
        
        # Determine factorial sum
        factorial_Sum(factorial_Array, actual_Array_Size)    

    else:
        # If the input is greater than 2000, then faster to determine the factorial in a threaded manner
        try:
            # Determine factorial
            factorial_Array = Threader.factorial_Threader(input)

        except IndexError:
            # If the max digits of 50000 is exceeded, a index out og bounds error is thrown and this the array size has been exceeded
            print("Factorial output magnitude exceeds the allowed maximum number of digits")
            exit()


        # Determine factorial sum
        factorial_Sum(factorial_Array, len(factorial_Array))
              



def factorial_Sum(final_Factorial_Array, array_Size):

    ################################
    ### SUM the factorial digits ###
    ################################

    # Define counter for elements in the array that were amended during the factorial calculation
    array_Counter = np.subtract(array_Size, 1)
    factorial_Sum = 0

    # Begin summation
    while array_Counter  >= 0:
        factorial_Sum = np.add(factorial_Sum, final_Factorial_Array[array_Counter])
        array_Counter  = np.subtract(array_Counter, 1)

    
    
    print(factorial_Sum)    




def check_Input(input):

    #################################
    ### Validates factorial input ###
    #################################

    if (input >= 0):
        # If input is a positive integer
        return input

    elif(input < 0):
        # If input is a negetive integer, return absolute value
        return np.multiply(input, -1)

    else:
        # If input is not a integer value
        print("Input is not an INTEGER value")
        exit()




def main():

    #####################
    ### Main Function ###
    #####################

    # Start program timer
    start = time.perf_counter()

    # Define input interface between Docker run argument and the python script using the 'argpase' library     
    parser = argparse.ArgumentParser()
    parser.add_argument('input_Number', type=int)
    args = parser.parse_args()
    
    # Validate input
    args.input_Number = check_Input(args.input_Number)

    print(">>")

    # Perform factorial
    factorial(args.input_Number)

    # Uncomment the next 2 lines of code to display executiton time

    # finish = time.perf_counter()
    # print("Execution Time: "+ str(finish - start))



if __name__ == "__main__":

    main()
