"""###############################################################################################################################
                                                FACTORIAL THREADER - SUPPORT CLASS
                                    Threads the factorial process for large input numbers)

                                                    Created by: Yashiv Fakir
                                                    Created on: 14/04/2022
                                                            Version: 3
###############################################################################################################################"""


import numpy as np                                  # Used for all math operation
from Threads_Math_Class import Multiplier           # Support class for factorial multiplication
import concurrent.futures                           # Python library that initializes, governs and terminates threads 



class Threader:

    def factorial_Threader(input):

        ##########################################################################
        ### Partions the factorial task into threads and returns the factorial ###
        ##########################################################################

        # Maximum number of digits allowed for the factorial output
        MAX_Number_Of_Factorial_Output_Digits = 50000

        # Number of threads to execute each partitioned task
        number_Of_Threads = 4
        
        # Initializes empty zeros output array for each thread and set to 1
        thread_1_Factorial_List = [0] * MAX_Number_Of_Factorial_Output_Digits
        thread_1_Factorial_List[0] = 1
        thread_2_Factorial_List = [0] * MAX_Number_Of_Factorial_Output_Digits
        thread_2_Factorial_List[0] = 1
        thread_3_Factorial_List = [0] * MAX_Number_Of_Factorial_Output_Digits
        thread_3_Factorial_List[0] = 1
        thread_4_Factorial_List = [0] * MAX_Number_Of_Factorial_Output_Digits
        thread_4_Factorial_List[0] = 1

        # Initial actual size of each array to 1
        thread_1_List_Actual_Size = 1
        thread_2_List_Actual_Size = 1
        thread_3_List_Actual_Size = 1
        thread_4_List_Actual_Size = 1
        
        # Start factorial multiplication at 2
        i = 2
        while_Loop_Status = True
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
            while (while_Loop_Status):
               

                if ((np.add(i, number_Of_Threads)) == input):
                    # if another execution equals the input number, then complete one more execution and stop loop
                
                    # Initialize threads from 0 up until 0 + number of threads to perform multiplication
                    thread_1 = executor.submit(Multiplier.array_Int_Multiplier,  i, thread_1_List_Actual_Size, thread_1_Factorial_List)
                    thread_2 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 1), thread_2_List_Actual_Size, thread_2_Factorial_List)
                    thread_3 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 2), thread_3_List_Actual_Size, thread_3_Factorial_List)
                    thread_4 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 3), thread_4_List_Actual_Size, thread_4_Factorial_List)

                    # Wait for all threads to return
                    thread_1_Factorial_List = thread_1.result()
                    thread_2_Factorial_List = thread_2.result()
                    thread_3_Factorial_List = thread_3.result()
                    thread_4_Factorial_List = thread_4.result()

                    # Update the new actual size of the returned thread results
                    thread_1_List_Actual_Size = thread_1_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                    thread_2_List_Actual_Size = thread_2_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                    thread_3_List_Actual_Size = thread_3_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                    thread_4_List_Actual_Size = thread_4_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]

                   
                    # Also have to include the actual input mutiple as the i will stop at i - 1
                    thread_1 = executor.submit(Multiplier.array_Int_Multiplier, np.add(i, number_Of_Threads), thread_1_List_Actual_Size, thread_1_Factorial_List)
                    thread_1_Factorial_List = thread_1.result()
                    thread_1_List_Actual_Size = thread_1_Factorial_List[MAX_Number_Of_Factorial_Output_Digits - 1]
                    
                    # STOP loop
                    while_Loop_Status = False

                elif ((np.add(i, number_Of_Threads)) > input): 
                    # If one more execution exceeds the input, then would have to peform less than the number_of_threads until equal to the input and stop loop
                  
                    # Used to count how many thread operations were executed before reaching input limit
                    count = 0
                    

                    # Initialize the required threads
                    if ((i+1) == input):
        
                        count = 2
                        thread_1 = executor.submit(Multiplier.array_Int_Multiplier,  i, thread_1_List_Actual_Size, thread_1_Factorial_List)
                        thread_2 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 1), thread_2_List_Actual_Size, thread_2_Factorial_List)
                    

                    elif ((i+2) == input):
                    
                        count = 3
                        thread_1 = executor.submit(Multiplier.array_Int_Multiplier,  i, thread_1_List_Actual_Size, thread_1_Factorial_List)
                        thread_2 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 1), thread_2_List_Actual_Size, thread_2_Factorial_List)
                        thread_3 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 2), thread_3_List_Actual_Size, thread_3_Factorial_List)
                    
                    
                    else:
                        
                        count = 4
                        thread_1 = executor.submit(Multiplier.array_Int_Multiplier,  i, thread_1_List_Actual_Size, thread_1_Factorial_List)
                        thread_2 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 1), thread_2_List_Actual_Size, thread_2_Factorial_List)
                        thread_3 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 2), thread_3_List_Actual_Size, thread_3_Factorial_List)
                        thread_4 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 3), thread_4_List_Actual_Size, thread_4_Factorial_List)

                        
                    
                    # Wait for the required threads to return
                    thread_1_Factorial_List = thread_1.result()
                    thread_1_List_Actual_Size = thread_1_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]

                    if (count == 2):
                        thread_2_Factorial_List = thread_2.result()
                        thread_2_List_Actual_Size = thread_2_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]

                    elif (count == 3):
                        thread_2_Factorial_List = thread_2.result()
                        thread_2_List_Actual_Size = thread_2_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                        thread_3_Factorial_List = thread_3.result()
                        thread_3_List_Actual_Size = thread_3_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]

                    elif (count == 4):
                        thread_2_Factorial_List = thread_2.result()
                        thread_2_List_Actual_Size = thread_2_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                        thread_3_Factorial_List = thread_3.result()
                        thread_3_List_Actual_Size = thread_3_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                        thread_4_Factorial_List = thread_4.result()
                        thread_4_List_Actual_Size = thread_4_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]


                    
                    # STOP loop
                    while_Loop_Status = False

                else:
                    # Else at least 2 or more itterations are required before stopping so perform a complete loop
                    
                    # Initialize threads from 0 up until 0 + number of threads to perform multiplication
                    thread_1 = executor.submit(Multiplier.array_Int_Multiplier,  i, thread_1_List_Actual_Size, thread_1_Factorial_List)
                    thread_2 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 1), thread_2_List_Actual_Size, thread_2_Factorial_List)
                    thread_3 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 2), thread_3_List_Actual_Size, thread_3_Factorial_List)
                    thread_4 = executor.submit(Multiplier.array_Int_Multiplier,  np.add(i, 3), thread_4_List_Actual_Size, thread_4_Factorial_List)

                    # Wait for all threads to return
                    thread_1_Factorial_List = thread_1.result()
                    thread_2_Factorial_List = thread_2.result()
                    thread_3_Factorial_List = thread_3.result()
                    thread_4_Factorial_List = thread_4.result()

                    # Update the new actual size of the returned thread results
                    thread_1_List_Actual_Size = thread_1_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                    thread_2_List_Actual_Size = thread_2_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                    thread_3_List_Actual_Size = thread_3_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]
                    thread_4_List_Actual_Size = thread_4_Factorial_List[np.subtract(MAX_Number_Of_Factorial_Output_Digits, 1)]

                    # Increment i by number of threads to next multiple    
                    i = np.add(i, number_Of_Threads) 
                    


            
            # Once the thread operations are completed, then need to multiply the output of each thread to determine the factorial
            
            # Format the output thread arrays for the multiplication method
            thread_1_Factorial_List, thread_2_Factorial_List = Multiplier.format_Array(thread_1_Factorial_List, thread_2_Factorial_List)
            thread_3_Factorial_List, thread_4_Factorial_List = Multiplier.format_Array(thread_3_Factorial_List, thread_4_Factorial_List)


            # Determine multiplication of each thread
            thread_5 = executor.submit(Multiplier.array__Array_Multiplier, thread_1_Factorial_List, thread_2_Factorial_List, thread_1_Factorial_List[len(thread_1_Factorial_List) - 1], thread_2_Factorial_List[len(thread_2_Factorial_List) - 1])
            thread_6 = executor.submit(Multiplier.array__Array_Multiplier, thread_3_Factorial_List, thread_4_Factorial_List, thread_3_Factorial_List[len(thread_3_Factorial_List) - 1], thread_4_Factorial_List[len(thread_4_Factorial_List) - 1])

            # Return results
            A_Array = thread_5.result()
            B_Array = thread_6.result()
 

        # Format the output thread arrays for the multiplication method
        A_Array = A_Array[::-1]
        B_Array = B_Array[::-1]

        # Multiply one more time
        final_Array = Multiplier.array__Array_Multiplier(A_Array, B_Array, len(A_Array), len(B_Array))
        
        return final_Array