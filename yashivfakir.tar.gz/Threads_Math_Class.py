"""###############################################################################################################################
                                    MULTIPLICATION FOR FACTORIAL ADDER - SUPPORT CLASS 
                        (Formats and multiplies arrays with either an array or integer value)

                                                Created by: Yashiv Fakir
                                                Created on: 14/04/2022
                                                        Version: 1
###############################################################################################################################"""

import numpy as np      # Used for all math operation


class Multiplier:
    
    def array_Int_Multiplier(i, actual_Array_Size, parsed_Factorial_Array):

        ###################################################################
        ### Parsed Integer Value Array Multiplied with an Integer Value ###
        ###################################################################

        # Instead of moving from right to left as
        # was taught in school for multiplication, the 
        # algorithm moves from left to right as the
        # counter begins at 2 and increases from units 
        # to tens, to hundredths etc. Therefore the 
        # factorial output sequence would be in reverse

        # For example:
            # 1234 x 10
            
            # where current array size is 4 
            # and carry initially set as 0
                # 4321
                # x 10
                #--------------------------------------------------
                # i = 0: product = 10 * 4 + 0 = 40,  0 add to array
                #                                    4 set as carry
                #--------------------------------------------------
                # i = 1: product = 10 * 3 + 4 = 34,  4 add to array
                #                                    3 set as carry
                #--------------------------------------------------
                # i = 2: product = 10 * 2 + 3 = 23   3 add to array
                #                                    2 set as carry
                #--------------------------------------------------
                # i = 3: product = 10 * 1 + 2 = 12   2 add to array
                #                                    1 set as carry
                #--------------------------------------------------
                # (LAST multiplication operation)
                # i = 4: product = 10 * 0 + 1 = 01    1 add to array   
                # Carry is now zero so end algorithm

                # Therefore: 1234 * 10 = 04321 when reversed = 12340 

        # Maximum number of digits allowed for the factorial output
        #MAX_Number_Of_Factorial_Output_Digits = 50000

        # Define carry variable
        multiplication_carry = 0 

        j = 0

        # Perform column multiplication and add the carry up until one 
        # before the last multiplication operation.
        
        while j < actual_Array_Size:
            # Perform multiplication operation
            product = np.multiply(parsed_Factorial_Array[j], i)
            product = np.add(product, multiplication_carry) 
            # Add the unit digit to the array
            parsed_Factorial_Array[j] = np.mod(product, 10) 
            # Carry the remainder                  
            multiplication_carry  = np.floor_divide(product, 10) 
            # Move to the next digit/column in the array
            j = np.add(j, 1)
                
        # Once at the last operation, perform the last multipication 
        # operation using the carry method and increment the array size
        # to account for any changes in size to the parsed array. 

        while (multiplication_carry):
            parsed_Factorial_Array[actual_Array_Size] = np.mod(multiplication_carry, 10)
                    
            multiplication_carry  = np.floor_divide(multiplication_carry, 10)
            actual_Array_Size = np.add(actual_Array_Size, 1)  
        
        # return the new array size   
        parsed_Factorial_Array[len(parsed_Factorial_Array) - 1] = actual_Array_Size
        
        return parsed_Factorial_Array

    
    


    def format_Array(array_1, array_2):

        ####################################################################
        ### Formats and reverses array for the array_Multiplier() method ###
        ####################################################################

        # As the actual array size if stored in the last digit of the array need to set to zero before shifting
        length_1 = array_1[np.subtract(len(array_1), 1)]
        array_1[np.subtract(len(array_1), 1)] = 0
        length_2 = array_2[np.subtract(len(array_2), 1)]
        array_2[np.subtract(len(array_2), 1)] = 0

        # Determine how much the arrays need to be shifted
        shift_Value_array_1 = np.multiply(np.subtract(len(array_1), length_1 ), -1)
        shift_Value_array_2 = np.multiply(np.subtract(len(array_2), length_2 ), -1)

        # Shift and reverse array 1
        array_1 = array_1[::-1]
        array_1 = np.array(array_1)
        array_1 = np.roll(array_1, shift_Value_array_1)

        # Shift and reverse array 2
        array_2 = array_2[::-1]
        array_2 = np.array(array_2)
        array_2 = np.roll(array_2, shift_Value_array_2)

        # Add actual length back to the array after shifting
        array_1[np.subtract(len(array_1), 1)] = length_1
        array_2[np.subtract(len(array_2), 1)] = length_2

        return array_1, array_2



    def array__Array_Multiplier(array_1, array_2, array_1_Length, array_2_Length):
        
        #######################################################################################
        ### Multiplies a parsed integer value array with another parsed integer value array ###
        #######################################################################################

        # Initialize the output array with empty zeros array
        product_Array = [0] * (array_1_Length + array_2_Length)
        
        # Inde 1 and 2 used to index product_Array
        product_Array_Index_1 = 0
        product_Array_Index_2 = 0

        # Start indexing array 1 from the last position
        for i in range(array_1_Length - 1, -1, -1):
            
            # Reset index_2 and carry variables
            carry = 0
            product_Array_Index_2 = 0

            # Start indexing array 2 from the last position            
            for j in range(array_2_Length - 1, -1, -1):
                
                # Determine the multiplication of array_1 and array_2 elements and add carry
                sum = np.add(np.multiply(array_1[i], array_2[j]), np.add(product_Array[np.add(product_Array_Index_1, product_Array_Index_2)], carry))

                # Determine new carry
                carry = np.floor_divide(sum, 10)

                # Store units element
                product_Array[np.add(product_Array_Index_1, product_Array_Index_2)] = np.mod(sum, 10)

                # Increment index 1
                product_Array_Index_2 = np.add(product_Array_Index_2, 1)

            
            if (carry > 0):
                # if carry not zero, add to the product array
                product_Array[np.add(product_Array_Index_1, product_Array_Index_2)] = np.add(product_Array[np.add(product_Array_Index_1, product_Array_Index_2)], carry)

            # Increment index 1
            product_Array_Index_1 = np.add(product_Array_Index_1, 1)
        
        return product_Array























  